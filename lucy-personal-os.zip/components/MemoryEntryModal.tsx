import React, { useState } from 'react';
import { Category, MemoryItem } from '../types';
import { Plus, Trash2 } from './Icons';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (category: Category, description: string, details: string[]) => void;
}

const MemoryEntryModal: React.FC<Props> = ({ isOpen, onClose, onSave }) => {
  const [category, setCategory] = useState<Category>('development');
  const [description, setDescription] = useState('');
  const [detailInput, setDetailInput] = useState('');
  const [details, setDetails] = useState<string[]>([]);

  if (!isOpen) return null;

  const handleAddDetail = () => {
    if (detailInput.trim()) {
      setDetails([...details, detailInput.trim()]);
      setDetailInput('');
    }
  };

  const handleRemoveDetail = (index: number) => {
    setDetails(details.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;
    onSave(category, description, details);
    // Reset
    setDescription('');
    setDetails([]);
    setDetailInput('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden animate-fade-in-up">
        <div className="bg-brand-50 p-6 border-b border-brand-100">
          <h2 className="text-xl font-semibold text-brand-900">New Memory Entry</h2>
          <p className="text-sm text-brand-600">Record your journey for Lucy to remember.</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {/* Category Selection */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
            <div className="grid grid-cols-3 gap-2">
              {(['struggles', 'development', 'mindset'] as Category[]).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                    category === cat
                      ? 'bg-brand-600 text-white shadow-md'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  } capitalize`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Main Description</label>
            <input
              type="text"
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g., Expanded poultry farm operations..."
              className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
            />
          </div>

          {/* Details List */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Details / Examples</label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={detailInput}
                onChange={(e) => setDetailInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddDetail())}
                placeholder="Add a specific detail..."
                className="flex-1 px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 outline-none"
              />
              <button
                type="button"
                onClick={handleAddDetail}
                className="bg-slate-800 text-white p-2 rounded-lg hover:bg-slate-900 transition-colors"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
            
            <ul className="space-y-2 max-h-32 overflow-y-auto">
              {details.map((detail, idx) => (
                <li key={idx} className="flex items-center justify-between bg-slate-50 px-3 py-2 rounded text-sm text-slate-700 border border-slate-100">
                  <span>{detail}</span>
                  <button type="button" onClick={() => handleRemoveDetail(idx)} className="text-red-400 hover:text-red-600">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </li>
              ))}
              {details.length === 0 && (
                <li className="text-xs text-slate-400 italic">No details added yet.</li>
              )}
            </ul>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-brand-600 text-white rounded-lg hover:bg-brand-700 shadow-lg shadow-brand-200 transition-all font-medium"
            >
              Save Memory
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MemoryEntryModal;
