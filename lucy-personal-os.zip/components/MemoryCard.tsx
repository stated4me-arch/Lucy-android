import React from 'react';
import { MemoryItem, Category } from '../types';
import { Brain, ShieldAlert, Sprout } from './Icons';

interface Props {
  item: MemoryItem;
  category: Category;
}

const MemoryCard: React.FC<Props> = ({ item, category }) => {
  const getIcon = () => {
    switch (category) {
      case 'struggles': return <ShieldAlert className="w-5 h-5 text-amber-600" />;
      case 'development': return <Sprout className="w-5 h-5 text-emerald-600" />;
      case 'mindset': return <Brain className="w-5 h-5 text-indigo-600" />;
    }
  };

  const getColorClass = () => {
    switch (category) {
      case 'struggles': return 'border-amber-200 bg-amber-50 hover:border-amber-300';
      case 'development': return 'border-emerald-200 bg-emerald-50 hover:border-emerald-300';
      case 'mindset': return 'border-indigo-200 bg-indigo-50 hover:border-indigo-300';
    }
  };

  const dateStr = new Date(item.timestamp).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });

  return (
    <div className={`p-5 rounded-xl border transition-all duration-300 hover:shadow-md ${getColorClass()}`}>
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-white rounded-lg shadow-sm">
            {getIcon()}
          </div>
          <span className="text-xs font-semibold uppercase tracking-wider opacity-60 text-slate-900">
            {category}
          </span>
        </div>
        <span className="text-xs text-slate-500 font-mono">{dateStr}</span>
      </div>
      
      <h3 className="text-lg font-bold text-slate-800 mb-2 leading-tight">
        {item.value.description}
      </h3>
      
      {item.value.details && item.value.details.length > 0 && (
        <ul className="space-y-1 mt-3">
          {item.value.details.map((detail, idx) => (
            <li key={idx} className="flex items-start text-sm text-slate-700">
              <span className="mr-2 mt-1.5 w-1 h-1 rounded-full bg-slate-400 shrink-0"></span>
              <span className="opacity-90">{detail}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default MemoryCard;
