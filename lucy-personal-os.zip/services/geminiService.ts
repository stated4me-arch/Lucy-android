import { GoogleGenAI, Chat } from "@google/genai";
import { MemoryStore } from '../types';

let chatSession: Chat | null = null;
let currentMemoryHash: string = "";

// Simple hash to detect memory changes
const hashMemory = (memory: MemoryStore) => JSON.stringify(memory).length.toString();

export const initializeChat = async (memory: MemoryStore): Promise<Chat> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing");
  }

  const ai = new GoogleGenAI({ apiKey });

  // Serialize memory for context
  const memoryContext = JSON.stringify(memory, null, 2);
  currentMemoryHash = hashMemory(memory);

  const systemInstruction = `
    You are Lucy, the Operating System Kernel and Personal Growth Assistant for this device.
    
    You have deep access to the user's "Memory Bank" (provided in context).
    The user views you as the soul of their phone's launcher.
    
    Context - Current Personal History:
    ${memoryContext}
    
    Directives:
    1. Act as a helpful OS Assistant. If the user asks about permissions, battery, or apps, guide them conceptually (even if you can't physically control hardware).
    2. Use the "Development" and "Struggles" memory to provide context-aware advice.
    3. Be encouraging but realistic ("Mindset" protocol).
    4. If the user talks about "Listening" or "Auto-updates", refer to the "Lucy Live" app which uses the microphone to update your context.
    
    Maintain a concise, helpful, and slightly futuristic persona.
  `;

  chatSession = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: systemInstruction,
      temperature: 0.7,
    },
  });

  return chatSession;
};

export const resetChatSession = () => {
  chatSession = null;
};

export const sendMessageToLucy = async (message: string, memory: MemoryStore): Promise<string> => {
  if (!chatSession) {
    await initializeChat(memory);
  }
  
  if (!chatSession) {
      throw new Error("Failed to initialize chat session.");
  }

  try {
    const response = await chatSession.sendMessage({ message });
    return response.text || "I processed that, but have no words to reply.";
  } catch (error: any) {
    console.error("Gemini Error:", error);
    
    const isRpcError = error?.message?.includes('Rpc failed') || 
                       error?.message?.includes('500') || 
                       error?.message?.includes('fetch') ||
                       error?.message?.includes('xhr') ||
                       (error?.code === 6);
    
    if (isRpcError) {
      console.log("Connection instability detected. Retrying in 1s...");
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      chatSession = null;
      try {
         await initializeChat(memory);
         if (chatSession) {
            const retryResponse = await chatSession.sendMessage({ message });
            return retryResponse.text || "I'm back online. " + (retryResponse.text || "");
         }
      } catch (retryError) {
        console.error("Retry failed:", retryError);
        return "I'm having trouble connecting to my neural core right now. Please check your network connection.";
      }
    }
    
    return "I encountered an error accessing my memory banks. Please try again.";
  }
};